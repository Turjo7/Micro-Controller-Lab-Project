/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
@TemplateRegistration(folder = "Other", content = "GcodeTemplate.gcode")
package com.willwinder.ugs.nbp.editor.type;

import org.netbeans.api.templates.TemplateRegistration;
