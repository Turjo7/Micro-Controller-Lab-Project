/*
    Copyright 2016-2018 Will Winder

    This file is part of Universal Gcode Sender (UGS).

    UGS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    UGS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with UGS.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.willwinder.universalgcodesender.listeners;

import com.willwinder.universalgcodesender.model.Position;

/**
 *
 * @author wwinder
 */
public class ControllerStatus {
    private final String stateString;
    private final Position machineCoord;
    private final Position workCoord;
    private final Position workCoordinateOffset;
    private final Double feedSpeed;
    private final Double spindleSpeed;
    private final OverridePercents overrides;
    private final EnabledPins pins;
    private final AccessoryStates accessoryStates;
    private final ControllerState state;

    /**
     * Baseline constructor. This data should always be present. Represents the
     * controller status.
     * @param stateString controller state, i.e. idle/hold/running
     * @param state controller state, i.e. {@link ControllerState#IDLE}/{@link ControllerState#HOLD}/{@link ControllerState#RUN}
     * @param machineCoord controller machine coordinates
     * @param workCoord controller work coordinates
     */
    public ControllerStatus(String stateString, ControllerState state, Position machineCoord, Position workCoord) {
        this(stateString, state, machineCoord, workCoord, null, null, null, null, null, null);
    }

    /**
     * Additional parameters
     */
    public ControllerStatus(String stateString, ControllerState state, Position machineCoord,
                            Position workCoord, Double feedSpeed, Double spindleSpeed,
                            OverridePercents overrides, Position workCoordinateOffset,
                            EnabledPins pins, AccessoryStates states) {
        this.stateString = stateString;
        this.state = state;
        this.machineCoord = machineCoord;
        this.workCoord = workCoord;
        this.workCoordinateOffset = workCoordinateOffset;
        this.feedSpeed = feedSpeed;
        this.spindleSpeed = spindleSpeed;
        this.overrides = overrides;
        this.pins = pins;
        this.accessoryStates = states;
    }

    /**
     * Returns the controller state as a string.
     *
     * @deprecated because different controllers have different state strings it's unsafe to build logic using these strings. Use {@link ControllerStatus#getState()} instead.
     * @return the state as a string
     */
    public String getStateString() {
        return stateString;
    }

    public ControllerState getState() {
        return state;
    }

    public Position getMachineCoord() {
        return machineCoord;
    }

    public Position getWorkCoord() {
        return workCoord;
    }

    public Position getWorkCoordinateOffset() {
        return workCoordinateOffset;
    }

    public Double getFeedSpeed() {
        return feedSpeed;
    }

    public Double getSpindleSpeed() {
        return spindleSpeed;
    }

    public OverridePercents getOverrides() {
        return overrides;
    }

    public EnabledPins getEnabledPins() {
        return pins;
    }

    public AccessoryStates getAccessoryStates() {
        return accessoryStates;
    }

    public static class EnabledPins {
        final public boolean X;
        final public boolean Y;
        final public boolean Z;
        final public boolean Probe;
        final public boolean Door;
        final public boolean Hold;
        final public boolean SoftReset;
        final public boolean CycleStart;

        public EnabledPins(String enabled) {
            String enabledUpper = enabled.toUpperCase();
            X = enabledUpper.contains("X");
            Y = enabledUpper.contains("Y");
            Z = enabledUpper.contains("Z");
            Probe = enabledUpper.contains("P");
            Door = enabledUpper.contains("D");
            Hold = enabledUpper.contains("H");
            SoftReset = enabledUpper.contains("R");
            CycleStart = enabledUpper.contains("S");
        }
    }

    public static class AccessoryStates {
        final public boolean SpindleCW;
        final public boolean SpindleCCW;
        final public boolean Flood;
        final public boolean Mist;

        public AccessoryStates(String enabled) {
            String enabledUpper = enabled.toUpperCase();
            SpindleCW = enabledUpper.contains("S");
            SpindleCCW = enabledUpper.contains("C");
            Flood = enabledUpper.contains("F");
            Mist = enabledUpper.contains("M");
        }
    }

    public static class OverridePercents {
        final public int feed;
        final public int rapid;
        final public int spindle;
        public OverridePercents(int feed, int rapid, int spindle) {
            this.feed = feed;
            this.rapid = rapid;
            this.spindle = spindle;
        }
    }
}